import * as http from 'http';
import model from './model/model.json';
const server = http.createServer((_req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello, World!\n');
});
const port = 3000;
const hostname = "0.0.0.0"
server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
const build = [];
let obj = {};
for (const key in model) {
  if (key === "number_1") {
    const num = parseInt(model.number_1.N);
    obj.number_1 = num.toFixed(1);
  }
  if (key === "string_1") {
    const s1 = model.string_1.S;
    obj.string_1 = s1.trim();
  }
  if (key === "string_2") {
    let s2 = new Date(model.string_2.S);
    s2 = s2.getTime();
    obj.string_2 = s2;
  }
  if (key === "map_1") {
    let map = model.map_1.M.list_1.L;
    map = map.forEach((item) => {
      if(item === "N")
        const N = parseInt(item.N);
    });
  }
}
build.push(obj);
console.log(build);
